/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaCourseworkUP894039;

/**
 *
 * @author ft020
 */
public class Pizza_Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Pizza_Test Pizzatest = new Pizza_Test();
        Order_test orderTest = new Order_test();
        Pizzatest.testOutput();
        orderTest.testOutput();
        
        
       
  
       
     
    }
    
}
